import json

with open('bd_districts.json') as f:
	data = json.load(f)

print(data)



input()