from django.http import JsonResponse
from django.http import Http404
from django.shortcuts import render


# LOGIN VIEW ENDPOINT

def login(request):
    comments = [
        {'email' : 'John Smith',
        'password' : '@johnsmith',
        'text' : 'I agree!'}
       
    ]

    # context = {'comments' : comments}
    
    # return render(request, 'index.html', context)
    
    context = {'comments' : comments}
    return render(request, 'login.html',context)

    return JsonResponse({'comments' : comments})


def register(request):
    comments = [
        {'first_name' : 'John Smith',
        'last_name' : '@johnsmith',
        'email' : 'I agree!',
		'password' : 'John Smith',
        'confirm-password' : '@johnsmith',
        'text' : 'I agree!'},
		
		 {'first_name' : 'John Smith',
        'last_name' : '@johnsmith',
        'email' : 'I agree!',
		'password' : 'John Smith',
        'confirm-password' : '@johnsmith',
        'text' : 'I agree!'},
		
       
    ]

       #context = {'comments' : comments}

    #return render(request, 'register.html',context)
    return JsonResponse({'comments' : comments})
