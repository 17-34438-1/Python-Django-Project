from django.apps import AppConfig


class MedicConfig(AppConfig):
    name = 'medic'
